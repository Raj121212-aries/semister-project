
# (Optional placeholder for future ORM or helpers)
# Currently using raw sqlite3 in app.py
